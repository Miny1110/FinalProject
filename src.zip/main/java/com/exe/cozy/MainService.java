package com.exe.cozy;

public interface MainService {

}
