package com.exe.cozy.certification;

public interface CertificationService {

	public void certifiedPhoneNumber(String customerTel, String cerNum); 
}
