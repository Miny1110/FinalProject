package com.exe.cozy.point;

import java.util.List;

import com.exe.cozy.domain.PointDto;

public interface PointService {
	
	public int maxNum();

	public void insertData(PointDto dto);
	
	public List<PointDto> getList(String customerEmail);
	
	public void deleteData(String customerEmail);
	
	public int getTotal(String customerEmail);
}
