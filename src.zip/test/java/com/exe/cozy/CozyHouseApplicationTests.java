package com.exe.cozy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyHouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
